# todo-list-react

Simple ToDoList App build in React.js

This is the display of this app <br>
![](todo-list-react.gif)

If you want to run this app, you just need to clone this git repository and then simply type npm install & npm start in your terminal or command prompt. When the app running, your browser will open automatically and display this ToDoList.
