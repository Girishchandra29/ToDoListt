import React from 'react';

function About(){
    return (
        <React.Fragment>
            <h1>Abuot</h1>
            <p>This is ToDoList App v1.0</p>
        </React.Fragment>
    )
}

export default About;